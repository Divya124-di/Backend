# DevTinder APIs

## authRouter
-post /signup
-post /login
-post /logout

## profileRouter
-GET /profile/view
-PATCH /profile/edit
-PATCH /profile/password

